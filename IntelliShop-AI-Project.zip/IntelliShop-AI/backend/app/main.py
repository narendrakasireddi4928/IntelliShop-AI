from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func
from dotenv import load_dotenv
import os
from .database import Base, engine, get_db
from . import models, schemas
from .security import hash_password, verify_password, current_user, admin_user
from ai_engine.recommender import recommend, similar_products, evaluation_report

load_dotenv()
Base.metadata.create_all(bind=engine)
app = FastAPI(title="IntelliShop AI API", version="1.0.0", description="Personalized commerce and recommendation API")
origins = [os.getenv("FRONTEND_ORIGIN", "http://localhost:5173"), "http://127.0.0.1:5173"]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def product_dict(p):
    return {"id":p.id,"title":p.title,"category":p.category,"brand":p.brand,"description":p.description,
            "price":p.price,"rating":p.rating,"image_url":p.image_url,"stock":p.stock}

@app.get("/api/health")
def health(): return {"status":"ok","service":"IntelliShop AI"}

@app.post("/api/auth/register")
def register(data: schemas.RegisterIn, db: Session=Depends(get_db)):
    if db.query(models.User).filter_by(email=data.email.lower()).first(): raise HTTPException(409,"Email already registered")
    user=models.User(name=data.name,email=data.email.lower(),password_hash=hash_password(data.password))
    db.add(user); db.commit(); db.refresh(user)
    return {"user":{"id":user.id,"name":user.name,"email":user.email,"role":user.role}}

@app.post("/api/auth/login")
def login(data: schemas.LoginIn, db: Session=Depends(get_db)):
    user=db.query(models.User).filter_by(email=data.email.lower()).first()
    if not user or not verify_password(data.password,user.password_hash): raise HTTPException(401,"Incorrect email or password")
    return {"user":{"id":user.id,"name":user.name,"email":user.email,"role":user.role}}

@app.get("/api/auth/me")
def me(user=Depends(current_user)):
    return {"id":user.id,"name":user.name,"email":user.email,"role":user.role,"preferences":user.preferences}

@app.get("/api/products")
def products(q: str="", category: str="", db: Session=Depends(get_db)):
    query=db.query(models.Product)
    if q: query=query.filter(models.Product.title.ilike(f"%{q}%") | models.Product.description.ilike(f"%{q}%") | models.Product.brand.ilike(f"%{q}%"))
    if category and category!="All": query=query.filter(models.Product.category==category)
    return [product_dict(p) for p in query.order_by(models.Product.id).all()]

@app.get("/api/products/{product_id}")
def product_detail(product_id:int, db:Session=Depends(get_db)):
    p=db.get(models.Product,product_id)
    if not p: raise HTTPException(404,"Product not found")
    return product_dict(p)

@app.post("/api/interactions")
def track(data:schemas.InteractionIn, db:Session=Depends(get_db)):
    if data.event_type not in ["view","click","wishlist","purchase"]: raise HTTPException(400,"Unsupported event")
    if not db.get(models.User,data.user_id) or not db.get(models.Product,data.product_id): raise HTTPException(404,"User or product not found")
    db.add(models.Interaction(**data.model_dump())); db.commit()
    return {"tracked":True}

@app.get("/api/recommendations/{user_id}")
def recommendations(user_id:int, db:Session=Depends(get_db)):
    if not db.get(models.User,user_id): raise HTTPException(404,"User not found")
    return [{"product":product_dict(x["product"]),"score":x["score"],"reason":x["reason"]} for x in recommend(db,user_id)]

@app.get("/api/products/{product_id}/similar")
def similar(product_id:int,db:Session=Depends(get_db)):
    return [{"product":product_dict(x["product"]),"score":x["score"],"reason":x["reason"]} for x in similar_products(db,product_id)]

@app.get("/api/wishlist")
def get_wishlist(user=Depends(current_user),db:Session=Depends(get_db)):
    rows=db.query(models.Wishlist).filter_by(user_id=user.id).all()
    return [product_dict(db.get(models.Product,r.product_id)) for r in rows]

@app.post("/api/wishlist")
def add_wishlist(product_id:int,user=Depends(current_user),db:Session=Depends(get_db)):
    if not db.get(models.Product,product_id): raise HTTPException(404,"Product not found")
    if not db.query(models.Wishlist).filter_by(user_id=user.id,product_id=product_id).first():
        db.add(models.Wishlist(user_id=user.id,product_id=product_id)); db.add(models.Interaction(user_id=user.id,product_id=product_id,event_type="wishlist")); db.commit()
    return {"saved":True}

@app.delete("/api/wishlist/{product_id}")
def remove_wishlist(product_id:int,user=Depends(current_user),db:Session=Depends(get_db)):
    db.query(models.Wishlist).filter_by(user_id=user.id,product_id=product_id).delete(); db.commit(); return {"removed":True}

@app.get("/api/cart")
def get_cart(user=Depends(current_user),db:Session=Depends(get_db)):
    return [{"product":product_dict(db.get(models.Product,r.product_id)),"quantity":r.quantity} for r in db.query(models.Cart).filter_by(user_id=user.id).all()]

@app.post("/api/cart")
def add_cart(data:schemas.CartIn,user=Depends(current_user),db:Session=Depends(get_db)):
    p=db.get(models.Product,data.product_id)
    if not p: raise HTTPException(404,"Product not found")
    row=db.query(models.Cart).filter_by(user_id=user.id,product_id=p.id).first()
    if row: row.quantity=min(20,row.quantity+data.quantity)
    else: db.add(models.Cart(user_id=user.id,product_id=p.id,quantity=data.quantity))
    db.add(models.Interaction(user_id=user.id,product_id=p.id,event_type="click")); db.commit(); return {"added":True}

@app.delete("/api/cart/{product_id}")
def remove_cart(product_id:int,user=Depends(current_user),db:Session=Depends(get_db)):
    db.query(models.Cart).filter_by(user_id=user.id,product_id=product_id).delete(); db.commit(); return {"removed":True}

@app.post("/api/checkout")
def checkout(user=Depends(current_user),db:Session=Depends(get_db)):
    rows=db.query(models.Cart).filter_by(user_id=user.id).all()
    if not rows: raise HTTPException(400,"Your cart is empty")
    total=0; order=models.Order(user_id=user.id,total=0); db.add(order); db.flush()
    for row in rows:
        p=db.get(models.Product,row.product_id)
        if not p or p.stock < row.quantity: raise HTTPException(400,f"Insufficient stock for {p.title if p else 'item'}")
        p.stock-=row.quantity; total+=p.price*row.quantity
        db.add(models.OrderItem(order_id=order.id,product_id=p.id,quantity=row.quantity,unit_price=p.price))
        db.add(models.Interaction(user_id=user.id,product_id=p.id,event_type="purchase"))
    order.total=round(total,2); db.query(models.Cart).filter_by(user_id=user.id).delete(); db.commit()
    return {"order_id":order.id,"total":order.total,"status":"Demo checkout complete"}

@app.post("/api/ratings")
def rate(data:schemas.RatingIn,db:Session=Depends(get_db)):
    row=db.query(models.Rating).filter_by(user_id=data.user_id,product_id=data.product_id).first()
    if row: row.score=data.score; row.review=data.review
    else: db.add(models.Rating(**data.model_dump()))
    db.commit(); return {"saved":True}

@app.get("/api/admin/overview")
def admin_overview(user=Depends(admin_user),db:Session=Depends(get_db)):
    events=db.query(models.Interaction).all()
    counts={k:sum(1 for e in events if e.event_type==k) for k in ["view","click","wishlist","purchase"]}
    views=counts["view"]; purchases=counts["purchase"]
    return {"customers":db.query(models.User).filter_by(role="customer").count(),"products":db.query(models.Product).count(),
            "interactions":len(events),"views":views,"purchases":purchases,"conversion_rate":round(purchases/views*100,2) if views else 0,
            "events":[{"name":k.title(),"value":v} for k,v in counts.items()]}
@app.get("/api/admin/customers")
def admin_customers(user=Depends(admin_user),db:Session=Depends(get_db)):
    return [{"id":u.id,"name":u.name,"email":u.email,"created_at":u.created_at.isoformat()} for u in db.query(models.User).filter_by(role="customer").all()]
@app.get("/api/admin/interactions")
def admin_interactions(user=Depends(admin_user),db:Session=Depends(get_db)):
    rows=db.query(models.Interaction).order_by(models.Interaction.created_at.desc()).limit(100).all()
    return [{"id":r.id,"user_id":r.user_id,"product":db.get(models.Product,r.product_id).title,"event_type":r.event_type,"created_at":r.created_at.isoformat()} for r in rows]
@app.get("/api/admin/evaluation")
def admin_evaluation(user=Depends(admin_user)): return evaluation_report()
@app.post("/api/admin/products")
def admin_add(data:schemas.ProductIn,user=Depends(admin_user),db:Session=Depends(get_db)):
    p=models.Product(**data.model_dump()); db.add(p); db.commit(); db.refresh(p); return product_dict(p)
@app.put("/api/admin/products/{pid}")
def admin_update(pid:int,data:schemas.ProductIn,user=Depends(admin_user),db:Session=Depends(get_db)):
    p=db.get(models.Product,pid)
    if not p: raise HTTPException(404,"Product not found")
    for k,v in data.model_dump().items(): setattr(p,k,v)
    db.commit(); return product_dict(p)
@app.delete("/api/admin/products/{pid}")
def admin_delete(pid:int,user=Depends(admin_user),db:Session=Depends(get_db)):
    p=db.get(models.Product,pid)
    if not p: raise HTTPException(404,"Product not found")
    db.delete(p); db.commit(); return {"deleted":True}
