from pydantic import BaseModel, EmailStr, Field, ConfigDict

class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=100)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class ProductIn(BaseModel):
    title: str
    category: str
    brand: str = ""
    description: str
    price: float = Field(gt=0)
    rating: float = Field(default=4.2, ge=0, le=5)
    image_url: str
    stock: int = Field(default=20, ge=0)

class InteractionIn(BaseModel):
    user_id: int
    product_id: int
    event_type: str

class RatingIn(BaseModel):
    user_id: int
    product_id: int
    score: int = Field(ge=1, le=5)
    review: str = ""

class CartIn(BaseModel):
    user_id: int
    product_id: int
    quantity: int = Field(default=1, ge=1, le=20)

class UserOut(BaseModel):
    id: int
    name: str
    email: str
    role: str
    model_config = ConfigDict(from_attributes=True)
