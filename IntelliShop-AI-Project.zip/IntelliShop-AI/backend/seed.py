from app.database import Base, engine, SessionLocal
from app.models import User, Product, Interaction
from app.security import hash_password
import csv, pathlib

Base.metadata.create_all(bind=engine)
db=SessionLocal()
if db.query(Product).count()==0:
    with open(pathlib.Path(__file__).parent.parent/"datasets"/"products.csv",encoding="utf-8") as f:
        for row in csv.DictReader(f):
            db.add(Product(title=row["title"],category=row["category"],brand=row["brand"],description=row["description"],
                           price=float(row["price"]),rating=float(row["rating"]),image_url=row["image_url"],stock=int(row["stock"])))
    db.commit()
if not db.query(User).filter_by(email="admin@intellishop.ai").first():
    db.add(User(name="IntelliShop Admin",email="admin@intellishop.ai",password_hash=hash_password("Admin123!"),role="admin"))
if not db.query(User).filter_by(email="maya@example.com").first():
    demo=[User(name="Maya Chen",email="maya@example.com",password_hash=hash_password("Password123!")),
          User(name="Arjun Rao",email="arjun@example.com",password_hash=hash_password("Password123!")),
          User(name="Sam Taylor",email="sam@example.com",password_hash=hash_password("Password123!"))]
    db.add_all(demo); db.commit()
    products=db.query(Product).all()
    for user, picks in zip(demo, [[0,1,4],[2,3,5],[0,2,6]]):
        for idx in picks:
            if idx < len(products):
                db.add(Interaction(user_id=user.id,product_id=products[idx].id,event_type="purchase" if idx%2 else "view"))
    db.commit()
db.close()
print("Database ready. Admin: admin@intellishop.ai / Admin123!")
