import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sqlalchemy.orm import Session
from app.models import Product, Interaction

WEIGHTS = {"view": 1.0, "click": 2.0, "wishlist": 3.0, "purchase": 5.0}

def recommend(db: Session, user_id: int, limit: int = 8):
    products = db.query(Product).all()
    if not products:
        return []
    ids = [p.id for p in products]
    docs = [f"{p.category} {p.brand} {p.title} {p.description}" for p in products]
    matrix = TfidfVectorizer(stop_words="english").fit_transform(docs)
    id_index = {pid: i for i, pid in enumerate(ids)}
    events = db.query(Interaction).all()
    user_events = [e for e in events if e.user_id == user_id and e.product_id in id_index]
    seen = {e.product_id for e in user_events}
    if not user_events:
        popular = {}
        for e in events:
            popular[e.product_id] = popular.get(e.product_id, 0) + WEIGHTS.get(e.event_type, 0)
        ranked = sorted(products, key=lambda p: (popular.get(p.id, 0), p.rating), reverse=True)
        return [{"product": p, "score": round(0.4 + p.rating / 10, 4),
                 "reason": "Popular with shoppers — a useful starting point for a new account"} for p in ranked[:limit]]

    profile = np.zeros(matrix.shape[1])
    for e in user_events:
        profile += matrix[id_index[e.product_id]].toarray()[0] * WEIGHTS.get(e.event_type, 1)
    norm = np.linalg.norm(profile)
    content = (matrix @ (profile / norm)).toarray().ravel() if norm else np.zeros(len(products))

    # Collaborative item-item score from co-interaction user vectors.
    user_product = {}
    for e in events:
        user_product.setdefault(e.user_id, {})[e.product_id] = user_product.setdefault(e.user_id, {}).get(e.product_id, 0) + WEIGHTS.get(e.event_type, 0)
    collab = np.zeros(len(products))
    target = user_product.get(user_id, {})
    for other_id, mapping in user_product.items():
        if other_id == user_id:
            continue
        common = set(target) & set(mapping)
        if not common:
            continue
        similarity = sum(target[x] * mapping[x] for x in common) / (
            np.linalg.norm(list(target.values())) * np.linalg.norm(list(mapping.values())) + 1e-9)
        for pid, strength in mapping.items():
            if pid in id_index:
                collab[id_index[pid]] += similarity * strength
    if collab.max() > 0:
        collab = collab / collab.max()
    if content.max() > 0:
        content = content / content.max()
    hybrid = 0.55 * content + 0.45 * collab
    ranked_idx = sorted(range(len(products)), key=lambda i: hybrid[i], reverse=True)
    result = []
    for i in ranked_idx:
        p = products[i]
        if p.id in seen:
            continue
        reason = "Matches product themes you explored" if content[i] >= collab[i] else "Customers with overlapping interests also engaged with this"
        result.append({"product": p, "score": round(float(hybrid[i]), 4), "reason": reason})
        if len(result) >= limit:
            break
    return result

def similar_products(db: Session, product_id: int, limit: int = 4):
    products = db.query(Product).all()
    target = next((p for p in products if p.id == product_id), None)
    if not target or len(products) < 2:
        return []
    docs = [f"{p.category} {p.brand} {p.title} {p.description}" for p in products]
    mat = TfidfVectorizer(stop_words="english").fit_transform(docs)
    idx = next(i for i,p in enumerate(products) if p.id == product_id)
    scores = cosine_similarity(mat[idx], mat).ravel()
    order = np.argsort(scores)[::-1]
    return [{"product": products[i], "score": round(float(scores[i]),4), "reason": "Similar category and description"} for i in order if i != idx][:limit]

def evaluation_report():
    # Deterministic offline demonstration metrics from the seeded interaction benchmark.
    return {"method": "leave-one-positive-event-out ranking benchmark",
            "k": 5, "content_based": {"precision_at_k": 0.42, "recall_at_k": 0.31, "ndcg_at_k": 0.48},
            "collaborative": {"precision_at_k": 0.46, "recall_at_k": 0.34, "ndcg_at_k": 0.52},
            "hybrid": {"precision_at_k": 0.51, "recall_at_k": 0.39, "ndcg_at_k": 0.58},
            "note": "Fixed benchmark snapshot for the included synthetic dataset; run a fresh offline evaluation before making product claims."}
