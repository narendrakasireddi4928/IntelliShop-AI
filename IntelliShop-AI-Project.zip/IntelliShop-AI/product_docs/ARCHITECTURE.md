# System Architecture
```text
React + Vite (browser)
      | REST / JSON, X-User-Id demo header
      v
FastAPI routes + Pydantic validation
      | SQLAlchemy ORM
      v
SQLite (users, products, events, ratings, wishlist, cart, orders)
      |
      +--> AI service: TF-IDF + cosine similarity + interaction co-occurrence
      +--> Admin analytics and offline evaluation snapshot
```
