# Product KPIs
- Recommendation CTR = recommendation clicks / recommendation impressions.
- Add-to-cart rate = sessions with add-to-cart / product detail sessions.
- Purchase conversion = purchase events / product views (directional in this demo).
- Precision@K = relevant recommended items in top K / K.
- Recall@K = relevant recommended items in top K / all held-out relevant items.
- NDCG@K = discounted gain normalized by ideal ranking.
- Guardrails: p95 API latency, opt-out rate, complaint rate, cold-start coverage, category exposure diversity.
