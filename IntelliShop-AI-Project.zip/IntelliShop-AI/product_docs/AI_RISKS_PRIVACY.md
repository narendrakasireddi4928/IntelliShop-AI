# AI Risks, Privacy & Responsible AI
- **Popularity bias:** add category coverage constraints and monitor exposure concentration.
- **Sparse/cold-start data:** show popular items and allow explicit preference selection; avoid overconfident claims.
- **Feedback loops:** monitor how recommendations influence future training events; retain exploration slots.
- **Proxy inference:** do not infer sensitive attributes or use them for ranking.
- **Privacy:** collect only necessary events, disclose purposes, define retention, provide access/deletion and opt-out controls.
- **Security:** hash passwords, protect admin routes, rotate secrets, use TLS and rate limiting in production.
- **Transparency:** show concise reasons and make clear that recommendations are automated suggestions.
- **Evaluation:** segment by new/returning users and category; validate on temporal holdouts before deployment.
- **Limitations:** current sample data is synthetic and dashboard benchmark values are illustrative, not a production performance claim.
