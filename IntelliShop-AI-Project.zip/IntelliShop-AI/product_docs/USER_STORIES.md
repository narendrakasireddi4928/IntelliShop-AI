# User Stories & Acceptance Criteria
- As a shopper, I can register with a valid email and password so my activity can be personalized. **AC:** duplicate emails return 409; invalid fields return validation errors.
- As a shopper, I can search and filter products. **AC:** query and category filters can be combined.
- As a shopper, I can see recommendations with reasons. **AC:** API returns product, score and explanation; new users receive popular fallback.
- As a shopper, I can save a product. **AC:** it appears in wishlist and a wishlist event is recorded.
- As an admin, I can inspect engagement. **AC:** overview shows counts, conversion and event breakdown.
- As an admin, I can inspect model evaluation. **AC:** Precision@K, Recall@K and NDCG@K are displayed with a note on dataset limitations.
