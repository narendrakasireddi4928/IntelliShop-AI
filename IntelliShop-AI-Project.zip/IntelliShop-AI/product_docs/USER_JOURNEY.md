# User Journey Map
| Stage | Shopper action | Pain point | IntelliShop response | Measurement |
|---|---|---|---|---|
| Discover | Opens home | Too many choices | Curated hero and popular products | Search engagement |
| Explore | Searches/filters | Irrelevant results | Search and category filters | Search-to-product CTR |
| Evaluate | Views item | Unsure what else fits | Similar items and rating | Detail-to-cart rate |
| Personalize | Saves/browses | Repeated generic results | Hybrid recommendations with reason | Recommendation CTR |
| Purchase | Adds to cart | Checkout friction | Simple demo checkout | Cart conversion |
| Return | Comes back | Context lost | Profile-based ranking | Repeat visit rate |
