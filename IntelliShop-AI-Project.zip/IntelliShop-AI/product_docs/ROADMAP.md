# Product Roadmap
| Phase | Timeline | Deliverables |
|---|---|---|
| 1. Foundation | Weeks 1–2 | Catalogue, accounts, event schema, SQLite |
| 2. Intelligence | Weeks 3–4 | TF-IDF, collaborative scoring, hybrid ranking, cold-start |
| 3. Experience | Weeks 5–6 | Explanations, wishlist, cart, responsive storefront |
| 4. Measurement | Weeks 7–8 | Admin dashboard, offline evaluation, A/B test design |
| 5. Production hardening | Later | PostgreSQL, JWT, migrations, privacy controls, monitoring |
