# User Personas
## Aanya — time-poor shopper
Wants to find trustworthy products quickly. Needs relevant ranking, category filters and clear reasons.

## Dev — exploration-led shopper
Browses many categories and saves items. Needs similar-item discovery and a useful wishlist.

## Priya — catalogue administrator
Maintains product quality and needs visibility into engagement, stock and recommendation performance.
