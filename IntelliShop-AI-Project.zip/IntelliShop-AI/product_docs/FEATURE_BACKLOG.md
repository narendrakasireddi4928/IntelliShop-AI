# Prioritized Feature Backlog
| Priority | Feature | Rationale |
|---|---|---|
| P0 | Registration/login | User identity for personalization |
| P0 | Catalogue/search/filter | Core discovery |
| P0 | Interaction tracking | Training signals |
| P0 | Hybrid recommendations | Main product value |
| P0 | Cold-start fallback | New-user experience |
| P1 | Similar products | Detail-page discovery |
| P1 | Wishlist/cart/checkout demo | Conversion journey |
| P1 | Admin analytics | Operational visibility |
| P1 | Evaluation report | Model accountability |
| P2 | Preference onboarding | Better cold-start signals |
| P2 | PostgreSQL + migrations | Scale and deployment |
| P2 | Experiment assignment service | Reliable A/B testing |
