# A/B Testing Plan
## Hypothesis
A hybrid recommender with explanations increases product recommendation CTR versus a popularity-only baseline.

## Design
Randomize eligible signed-in users into control (popular products) and treatment (hybrid recommendations), persist assignment per user, run for at least two full shopping weeks and calculate sample size from baseline CTR and minimum detectable effect before launch.

## Primary metric
Recommendation click-through rate.

## Secondary metrics
Add-to-cart rate, purchase conversion, NDCG@5, time to first relevant product.

## Guardrails
Latency, diversity of category exposure, opt-out/complaint rate, return/cancellation rate.

## Decision
Ship only if the pre-registered primary metric improves with statistical confidence and guardrails do not regress. Do not peek and stop early without a sequential-testing plan.
