# IntelliShop AI — Smart Product Recommendation Engine

A runnable portfolio project with a React/Vite storefront, FastAPI backend, SQLite database, and real scikit-learn recommendation models (TF-IDF content similarity + interaction-based collaborative scoring + hybrid ranking).

## Features
- Register/login (demo token authentication; passwords hashed with PBKDF2)
- Search, category filter, product detail, wishlist, cart, demo checkout
- Tracks views, clicks, wishlist additions and purchases
- Content-based TF-IDF + cosine similarity, collaborative interaction scoring, hybrid ranking
- Cold-start popular/trending fallback and recommendation explanations
- Admin dashboard with product CRUD, customers, interactions, metrics and offline model evaluation
- Product-management docs and basic API tests

> This is an educational portfolio implementation. Checkout is simulated; do not use it for real payments or production customer data. Admin credentials are `admin@intellishop.ai` / `Admin123!`.

## Requirements
- Windows 10/11
- Python 3.10+
- Node.js 18+

## Run in VS Code

### 1. Backend terminal (PowerShell)
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python seed.py
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` then activate again.

### 2. Frontend terminal (new terminal)
```powershell
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (normally http://localhost:5173). API docs: http://127.0.0.1:8000/docs.

### 3. Tests
With backend virtual environment active:
```powershell
cd backend
pytest -q
```

## Project architecture
React UI → FastAPI REST API → SQLAlchemy repositories → SQLite. The AI service reads product metadata and interaction events, computes TF-IDF vectors/cosine similarities and collaborative item scores, then blends normalized scores. The database URL is configurable through `DATABASE_URL`, so SQLite can later be replaced with PostgreSQL.

## Recommendation logic
- **Content-based:** TF-IDF vectorization over category, brand, title and description; cosine similarity to products the user has interacted with.
- **Collaborative:** co-occurrence from user-product interaction strengths (view=1, click=2, wishlist=3, purchase=5), with item-item cosine similarity.
- **Hybrid:** weighted content and collaborative scores (default 55% / 45%); popularity fallback for new users.
- **Evaluation:** leave-one-positive-interaction-out ranking evaluation with Precision@K, Recall@K and NDCG@K. Results are illustrative for the included synthetic dataset.

## Database
Tables: users, products, interactions, ratings, wishlist, cart, orders, order_items, recommendations. Foreign keys and uniqueness constraints protect core relationships. Tables are created automatically by `seed.py` or app startup.

## API
- `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET /api/products`, `GET /api/products/{id}`, `GET /api/products/{id}/similar`
- `POST /api/interactions`
- `GET /api/recommendations/{user_id}`
- `GET/POST/DELETE /api/wishlist`
- `GET/POST/DELETE /api/cart`, `POST /api/checkout`
- `GET/POST/PUT/DELETE /api/admin/products`
- `GET /api/admin/overview`, `/customers`, `/interactions`, `/evaluation`

All endpoints are documented in Swagger at `/docs`.

## Responsible AI & security notes
Use consent and clear explanations for behavioural personalization; minimize retained event data; provide deletion/export controls; restrict admin access; protect secrets; monitor popularity bias, feedback loops, demographic proxies and cold-start performance. Before production, add JWT sessions, rate limiting, CSRF strategy, migrations, payment provider integration, observability, privacy policy and security review.
