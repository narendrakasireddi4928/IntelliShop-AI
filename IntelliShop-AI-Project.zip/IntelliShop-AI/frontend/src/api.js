const API='http://127.0.0.1:8000/api';
export function setSession(user){localStorage.setItem('intellishop_user',JSON.stringify(user));}
export function getSession(){try{return JSON.parse(localStorage.getItem('intellishop_user')||'null')}catch{return null}}
export async function request(path,options={}){const user=getSession();const headers={'Content-Type':'application/json',...(options.headers||{})};if(user?.id)headers['X-User-Id']=user.id;
 const res=await fetch(API+path,{...options,headers});const data=await res.json().catch(()=>({detail:'Unexpected server response'}));if(!res.ok)throw new Error(data.detail||'Request failed');return data}
